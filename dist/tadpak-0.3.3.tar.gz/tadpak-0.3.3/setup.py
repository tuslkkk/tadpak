import setuptools

setuptools.setup(
        name="tadpak",
        version="0.3.3",
        license="MIT",
        author="SiwonKim",
        packages=setuptools.find_packages(),
)
